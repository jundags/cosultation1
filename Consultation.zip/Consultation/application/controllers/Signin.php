<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signin extends CI_Controller {

	public function index()
	{
		$this->load->view('Login');
	}

	public function register()
	{
		redirect(base_url('Signup'));	
	}
	public function login()
	{
		redirect(base_url('Account'));	
	}
}
