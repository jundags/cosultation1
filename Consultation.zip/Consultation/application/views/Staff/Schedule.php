<div class="container-fluid">
	<div class="row">
		<div class="col-sm-6">
			<h3>My Schedule</h3>
		</div>
		<div class="col-sm-6 text-right">
			<button class="btn btn-primary" data-toggle="modal" data-target="#createSched"><i class="fas fa-plus-circle"></i> <span>Create Schedule</span></button>
		</div>
	</div>
</div>