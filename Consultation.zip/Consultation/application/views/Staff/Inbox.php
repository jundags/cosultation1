<div class="container-fluid overflow-auto">
    <h3>Inbox</h3>
    <table class="table table-striped table-dark text-center">
    	<thead>
    		<tr>
	    		<th>No.</th>
	    		<th>Name</th>
	    		<th>Reason</th>
                <th>Schedule</th>
	    		<th>Action</th>
    		</tr>
    	</thead>
    	<tbody id="viewrequest">
    	</tbody>
    </table>
</div>