<div class="container-fluid">
	<div class="row">
		<div class="col-sm-6">
			<h3>Today's Schedule</h3>
		</div>
	</div>
</div>