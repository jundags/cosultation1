
<div class="container-fluid" >
	<table class="table table-striped table-light text-center">
        <thead>
            <tr>
                <th>Collage</th>
                <th>Deparment</th>
                <th>Name</th>
                <th>Action</th>     
            </tr>
        </thead>
        <tbody class="request">
            <td><select required="" class="form-control" name="college" id="college"></select></td>
            <td><select required="" class="form-control" name="department" id="department"></select></td>    
            <td><select required="" class="form-control" name="StaffNames" id="StaffNames"></select></td>
            <td><button class="btn btn-primary" data-toggle="modal" data-target="#createSched" id="reqbutton" disabled="false"><i class="fas fa-plus-circle"></i><span>Request Schedule</span></button></td>
        </tbody>
     </table>
 </div>
