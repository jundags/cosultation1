<div class="container-fluid">
	<div class="row">
		<div class="col-sm-6" style="margin-left: 380px;">
			<h1>WELCOME <font style="color: blue;"><?php  $str = strtoupper($name); echo $str;?></font> </h1>
		</div>
	</div>
</div>