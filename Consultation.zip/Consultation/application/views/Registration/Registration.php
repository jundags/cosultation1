<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/bootstrap/css/bootstrap.min.css"> 
    <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/fontawesome/css/all.css">  
	<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/registration.css">
    <script src="<?= base_url();?>assets/bootstrap/js/jquery.js"></script>
    <script src="<?= base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/js/script.js"></script>
</head>
<body>   
    <div class="container">
        <div id="selection">
            <h1 id="head" >User Type</h1>
            <div class="imgstudent"><button type="button" class="btn btn-primary btns1" onclick="studentbtn();">Student</button></div>
            <div class="imgstaff"><button type="button" class="btn btn-success btns2" onclick="facultybtn();">Faculty Staff</button></div>
       </div>
        <div id="register-right">
            <?php $this->load->view('Registration/RegFaculty')?>
        </div>
        <div id="register-left">
            <?php $this->load->view('Registration/RegStudent')?>
           </div>
        </div>  
</body>
</html>