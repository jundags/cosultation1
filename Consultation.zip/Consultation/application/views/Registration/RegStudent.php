<form action="" method="POST" data-toggle="validator" role="form">
<div class="register-form">
    <div class="col-md-6">
        <div class="form-group">
             <label>Username</label>
            <input type="text" class="form-control" placeholder="First Name *" value=""value="" required/>
        </div>
        <div class="form-group">
             <label>Lastname</label>
            <input type="text" class="form-control" placeholder="Middle Name *" value=""value="" required/>
        </div>
        <div class="form-group">
             <label>Lastname</label>
            <input type="text" class="form-control" placeholder="Last Name *" value=""value="" required/>
        </div>
        <div class="form-group">
             <label>DateOfBirth</label>
            <input type="text" class="form-control" placeholder="year/month/day *" value=""value="" required/>
        </div>
        <div class="form-group">
             <label>Password</label>
            <input type="password" class="form-control" placeholder="Password *" value=""value="" required/>
        </div>
        <div class="form-group">
             <label>Confirm-password</label>
            <input type="password" class="form-control"  placeholder="Confirm Password *" ata-match-error="Password does'nt match!" placeholder="Confirm Password *" value="" required />
        </div>
    </div>
    <div class="col-md-5">
        <div class="form-group gen"value="" required>
             <label>Gender</label><br>
            <input type="radio" name="gender" value="male" checked><span> Male </span><br>
            <input type="radio" name="gender" value="female"><span>Female </span>          
        </div>

        <div class="form-group">
            <label>Deparment</label>
            <select class="form-control"value="" required>
                <option value="COE">CoE - Computer Engineering</option>
                <option value="IT">IT - Information Technology</option>
            </select>
        </div>
        <div class="form-group">
             <label>Email</label>
            <input type="email" class="form-control" placeholder="Your Email *" value="" value="" required/>
        </div>
        <div class="form-group">
             <label>Phone No.</label>
            <input type="text" minlength="10" maxlength="10" name="txtEmpPhone" class="form-control" placeholder="Phone No *" value="" required/>
        </div>
        <input type="submit" class="btnRegister"  value="Register"/>
    </div>
    <div class="col-md-1 minimize" onclick="studentbtnback();">
        <span class="glyphicon glyphicon-chevron-left span1" ></span>
    </div>
</div>
</form>