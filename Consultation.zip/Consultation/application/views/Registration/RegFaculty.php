<form action="" method="POST" data-toggle="validator" role="form">
    <div class="register-form">
    <div class="col-md-1 minimize" onclick="facultybtnback();">
        <span class="glyphicon glyphicon-chevron-right span" ></span>
    </div>
    <div class="col-md-6 ">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control" placeholder="Username *" value="" required/>
        </div>
        <div class="form-group">
            <label>Firstname</label>
            <input type="text" name="firstname" class="form-control" placeholder="First Name *" value="" required/>
        </div>
        <div class="form-group">
            <label>Middlename</label>
            <input type="text" name="middlename" class="form-control" placeholder="Middle Name *" value="" required/>
        </div>
        <div class="form-group">
            <label>Lastname</label>
            <input type="text" name="lastname" class="form-control" placeholder="Last Name *" value="" required/>
        </div>
        <div class="form-group gend" data-placement="left">
            <label>Gender</label><br>
            <input type="radio" name="gender" value="male" checked><span> Male </span><br>
            <input type="radio" name="gender" value="female"><span>Female </span>          
        </div>
    </div>
    <div class="col-md-5">
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" id="pass" class="form-control" placeholder="Password *" value="" required/>
        </div>
        <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" name="conpassword" class="form-control" data-match="#pass" data-match-error="Password does'nt match!" placeholder="Confirm Password *" value="" required/>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" class="form-control" placeholder="Your Email *" value="" />
        </div>
        <div class="form-group">
            <label>Deparment</label>
            <select class="form-control">
                <option value="COE">CoE - Computer Engineering</option>
                <option value="IT">IT - Information Technology</option>
            </select>
        </div>
        
       
        <input type="submit" class="btnRegister"  value="Register"/>
    </div>
    </div>
</div>
</form>
