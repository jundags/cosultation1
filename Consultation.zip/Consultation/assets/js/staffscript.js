var time = "<option value=01:>"

$('#date').datepicker({
		dateFormat:"yy-mm-dd",
		changeMonth:true,
		changeYear:true
});
$('#datebutton').datepicker({
		dateFormat:"yy-mm-dd",
		changeMonth:true,
		changeYear:true
});
// $('#time1').timepicker();
// $('#time2').timepicker();
$(document).ready(function(){
	viewrequest();
	viewappointment();
	function viewrequest(){
		$.ajax({
			type:'ajax',
			url:'/Consultation/Account/viewRequest',
			async:'false',
			success:function(data){
				var output ='';
				var count=0;
				var reqdata = JSON.parse(data);

			    for(var i=0;i<reqdata.length;i++) {
			    count+=1;
				output +='<tr>'
			    			+'<td>'+count+'</td>'
			    			+'<td><a href="" data-toggle="modal" data-target="#studentinfo" class="nounderline" data="'+reqdata[i].id+'">'+reqdata[i].Student_Name+'</a></td>'
			    			+'<td>'+reqdata[i].Reason+'</td>'
			                +'<td>'+reqdata[i].Date+' <br> '+reqdata[i].time_start+'-'+reqdata[i].time_end+'</td>'
			    			+'<td><button class="btn btn-primary" id="submit" value="'+reqdata[i].id+'">Accept</button> &nbsp'
			    				+'<button class="btn btn-primary" id="decline" value="'+reqdata[i].id+'">Decline</button>'
			    			+'</td>'
			    		+'</tr>';
				}
				$('#viewrequest').html(output);
			}
		});

	}
	function viewappointment(){
		var date = $('#datebutton').val(); 
		$.ajax({
			url:'/Consultation/Account/viewAppointment',
			method:'post',
			data:{'date':date},
			success:function(data1){
				var output='';
				var data = JSON.parse(data1);
				for (var i = 0; i < data.length; i++) {
					output +='<tr>'
				                +'<td>'+(i+1)+'</td>'
				                +'<td><a href="" data-toggle="modal" data-target="#studentinfo" class="nounderline" data="'+data[i].student_id+'">'+data[i].studentName+'</a></td>'   
				                +'<td>'+data[i].timeStart+'-'+data[i].timeEnd+'</td>'
				                +'<td><button class="btn btn-primary" id="postpone" value="'+data[i].Request_id+'">Postpone</button>' 
				                +'<td>'+data[i].Status+'</td>'
				            +'</tr>';				
				}
				$('#viewappointment').html(output);
			},
			error:function(data){
				console.log(data);	
			}
		});
	}
	$('#datebutton').change(function(){
		viewappointment();
	});
	$('#viewappointment').on('click','#postpone',function(){
		var id = $(this).attr('value');
		$.ajax({
			url:'/Consultation/Account/decline_or_postpone',
			method:'post',
			data:{'id':id,'status':2},
			success:function(data){
				viewappointment();
			},
			error:function(data){
				console.log(data);
			}
		});
	});
	$('#viewrequest').on('click','#decline',function(){
		var id = $(this).attr('value');
		$.ajax({
			url:'/Consultation/Account/decline_or_postpone',
			method:'post',
			data:{'id':id,'status':3},
			success:function(data){
				viewrequest();
			},
			error:function(data){
				console.log(data);
			}
		});
	});
	$('#viewrequest').on('click','#submit',function(){
	var id = $(this).attr('value');
	$.ajax({
		url:'/Consultation/Account/submitRequest',
		method:'post',
		data:{'id':id},
		success:function(data){
			viewrequest();
			console.log(data);
		},
		error:function(data){
			alert(data);
		}
	});
});
});


