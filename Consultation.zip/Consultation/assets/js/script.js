function facultybtn() {
	document.getElementById('register-right').style.right="0px";
	document.getElementById('selection').style.top="25px";
	document.getElementById('head').innerHTML='Staff Registration';
}
function studentbtn() {
	document.getElementById('register-left').style.left="0px";
	document.getElementById('selection').style.top="25px";
	document.getElementById('head').innerHTML='Student Registration';
}
function facultybtnback() {
	document.getElementById('register-right').style.right="-1500px";
	document.getElementById('selection').style.top="200px";
	document.getElementById('head').innerHTML='User Type';
}
function studentbtnback() {
	document.getElementById('register-left').style.left="-1500px";
	document.getElementById('selection').style.top="200px";
	document.getElementById('head').innerHTML='User Type';
}
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});
